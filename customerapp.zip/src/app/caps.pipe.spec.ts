import { CapsPipe } from './caps.pipe';

describe('CapsPipe', () => {
  it('create an instance', () => {
    const pipe = new CapsPipe();
    expect(pipe).toBeTruthy();
  });
});
