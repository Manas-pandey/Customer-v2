import { Directive, Renderer2, ElementRef, HostListener, Input, HostBinding } from '@angular/core';

@Directive({
  selector: '[appHover]'
})
export class HoverDirective {
  @Input()
  selector: any;

  @HostBinding('style.border')
  border: string;

  constructor(private el: ElementRef, private renderer: Renderer2) { 
    // console.log(el.nativeElement);
  }

  @HostListener('mouseover')
  mouseOver(): void {
    const elem = this.el.nativeElement.querySelector(this.selector.option);
    this.renderer.setStyle(elem, 'display', 'none');
    this.border = '3px solid red';
  }

  @HostListener('mouseout')
  mouseOut(): void {
    // const elem = this.el.nativeElement;
    const elem = this.el.nativeElement.querySelector('.img');
    this.renderer.setStyle(elem, 'display', 'block');
    this.border = '';
  }
}
